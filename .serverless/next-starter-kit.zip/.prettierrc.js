module.exports = {
	useTabs: true,
	semi: true,
	singleQuote: true,
	trailingComma: 'all',
	arrowParens: 'always',
};
