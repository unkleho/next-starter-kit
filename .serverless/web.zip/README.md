# Next Starter Kit

## Based on nextjs-postcss branch
https://github.com/almeynman/nextjs-postcss
https://blog.intellection.kz/next-js-and-css-modules-37e785a98bb0
