
          window.__NEXT_REGISTER_PAGE('/example-page', function() {
            var comp = module.exports =
webpackJsonp([2],{

/***/ 385:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(386);


/***/ }),

/***/ 386:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _toConsumableArray2 = __webpack_require__(117);

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _getPrototypeOf = __webpack_require__(21);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(10);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(11);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(22);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(23);

var _inherits3 = _interopRequireDefault(_inherits2);

var _style = __webpack_require__(76);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(6);

var _react2 = _interopRequireDefault(_react);

var _propTypes = __webpack_require__(34);

var _propTypes2 = _interopRequireDefault(_propTypes);

var _examplePage = __webpack_require__(387);

var _examplePage2 = _interopRequireDefault(_examplePage);

var _withData = __webpack_require__(120);

var _withData2 = _interopRequireDefault(_withData);

var _ExampleApp = __webpack_require__(118);

var _ExampleApp2 = _interopRequireDefault(_ExampleApp);

var _Header = __webpack_require__(119);

var _Header2 = _interopRequireDefault(_Header);

var _ExampleComponent = __webpack_require__(388);

var _ExampleComponent2 = _interopRequireDefault(_ExampleComponent);

var _exampleActions = __webpack_require__(390);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var ExamplePage = function (_Component) {
  (0, _inherits3.default)(ExamplePage, _Component);

  function ExamplePage() {
    (0, _classCallCheck3.default)(this, ExamplePage);

    var _this = (0, _possibleConstructorReturn3.default)(this, (ExamplePage.__proto__ || (0, _getPrototypeOf2.default)(ExamplePage)).call(this));

    _this.state = {};
    return _this;
  }

  (0, _createClass3.default)(ExamplePage, [{
    key: 'render',
    value: function render() {
      var _props = this.props,
          id = _props.id,
          url = _props.url;

      var sizes = ['xxs', 'xs', 'sm', 'md', 'lg', 'xlg', 'xxlg'];
      var colours = ['primary', 'secondary', 'tertiary', 'highlight'];

      return _react2.default.createElement(_ExampleApp2.default, null, _react2.default.createElement(_Header2.default, { pathname: url.pathname }), _react2.default.createElement('h1', { className: 'title', 'data-jsx-ext': _examplePage2.default.__scopedHash
      }, 'Page ', _react2.default.createElement('span', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, id)), _react2.default.createElement('h2', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, 'Style Guide'), _react2.default.createElement('h3', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, 'Type Scale'), sizes.map(function (size) {
        return _react2.default.createElement('p', { className: 'font-size-' + size, key: 'font-size-' + size, 'data-jsx-ext': _examplePage2.default.__scopedHash
        }, 'font-size-' + size);
      }), _react2.default.createElement('h3', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, 'Colours'), colours.map(function (colour) {
        return _react2.default.createElement('div', { className: 'boxes', key: 'boxes-' + colour, 'data-jsx-ext': _examplePage2.default.__scopedHash
        }, _react2.default.createElement('h4', {
          'data-jsx-ext': _examplePage2.default.__scopedHash
        }, colour), _react2.default.createElement('div', {
          'data-jsx-ext': _examplePage2.default.__scopedHash
        }, [].concat((0, _toConsumableArray3.default)(Array(7))).map(function (shade, i) {
          return _react2.default.createElement('div', { className: 'box box--colour-' + colour, key: 'box--colour-' + colour + '-' + i, 'data-jsx-ext': _examplePage2.default.__scopedHash
          });
        })));
      }), _react2.default.createElement('h2', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, 'Example Component'), _react2.default.createElement(_ExampleComponent2.default, { title: 'Title' }), _react2.default.createElement('h2', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, 'dotenv Test'), _react2.default.createElement('p', {
        'data-jsx-ext': _examplePage2.default.__scopedHash
      }, undefined), _react2.default.createElement(_style2.default, {
        styleId: _examplePage2.default.__scopedHash,
        css: _examplePage2.default.__scoped
      }));
    }
  }], [{
    key: 'getInitialProps',
    value: function getInitialProps(_ref) {
      var _ref$query$id = _ref.query.id,
          id = _ref$query$id === undefined ? null : _ref$query$id,
          serverState = _ref.serverState;

      var store = (0, _withData.createApolloReduxStore)(serverState);
      store.dispatch((0, _exampleActions.exampleAction)('payload'));

      return {
        id: id
      };
    }
  }]);

  return ExamplePage;
}(_react.Component);

exports.default = (0, _withData2.default)(ExamplePage);

/***/ }),

/***/ 387:
/***/ (function(module, exports) {

var __styledJsxDefaultExport = new String(".paragraph{font-size:20px}h1{color:blue}p.font-size-xxs{font-size:0.45517em}p.font-size-xs{font-size:0.59172em}p.font-size-sm{font-size:0.76923em}p.font-size-md{font-size:1em}p.font-size-lg{font-size:1.3em}p.font-size-xlg{font-size:1.69em}p.font-size-xxlg{font-size:2.197em}.title{color:blue}.title span{color:green}.boxes:before{content:'';display:table}.boxes:after{content:'';display:table;clear:both}.box{background-color:green;padding:1em}@media (min-width:48em){.box{width:calc(99.9% * 1/7)}.box:nth-child(1n){float:left;margin-right:0;clear:none}.box:last-child{margin-right:0}.box:nth-child(0n){margin-right:0;float:right}.box:nth-child(0n + 1){clear:both}}.box--colour-primary{background-color:blue}.box--colour-secondary{background-color:green}.box--colour-tertiary{background-color:yellow}.box--colour-highlight{background-color:red}.box--colour-primary:nth-child(1){background-color:rgb(77, 77, 255)}.box--colour-primary:nth-child(2){background-color:rgb(51, 51, 255)}.box--colour-primary:nth-child(3){background-color:rgb(25, 25, 255)}.box--colour-primary:nth-child(5){background-color:rgb(0, 0, 230)}.box--colour-primary:nth-child(6){background-color:rgb(0, 0, 204)}.box--colour-primary:nth-child(7){background-color:rgb(0, 0, 179)}.box--colour-secondary:nth-child(1){background-color:rgb(77, 166, 77)}.box--colour-secondary:nth-child(2){background-color:rgb(51, 153, 51)}.box--colour-secondary:nth-child(3){background-color:rgb(25, 141, 25)}.box--colour-secondary:nth-child(5){background-color:rgb(0, 115, 0)}.box--colour-secondary:nth-child(6){background-color:rgb(0, 102, 0)}.box--colour-secondary:nth-child(7){background-color:rgb(0, 90, 0)}.box--colour-tertiary:nth-child(1){background-color:rgb(255, 255, 77)}.box--colour-tertiary:nth-child(2){background-color:rgb(255, 255, 51)}.box--colour-tertiary:nth-child(3){background-color:rgb(255, 255, 25)}.box--colour-tertiary:nth-child(5){background-color:rgb(230, 230, 0)}.box--colour-tertiary:nth-child(6){background-color:rgb(204, 204, 0)}.box--colour-tertiary:nth-child(7){background-color:rgb(179, 179, 0)}.box--colour-highlight:nth-child(1){background-color:rgb(255, 77, 77)}.box--colour-highlight:nth-child(2){background-color:rgb(255, 51, 51)}.box--colour-highlight:nth-child(3){background-color:rgb(255, 25, 25)}.box--colour-highlight:nth-child(5){background-color:rgb(230, 0, 0)}.box--colour-highlight:nth-child(6){background-color:rgb(204, 0, 0)}.box--colour-highlight:nth-child(7){background-color:rgb(179, 0, 0)}");

__styledJsxDefaultExport.__hash = "13125056293";
__styledJsxDefaultExport.__scoped = ".paragraph[data-jsx-ext~=\"23125056293\"]{font-size:20px}h1[data-jsx-ext~=\"23125056293\"]{color:blue}p.font-size-xxs[data-jsx-ext~=\"23125056293\"]{font-size:0.45517em}p.font-size-xs[data-jsx-ext~=\"23125056293\"]{font-size:0.59172em}p.font-size-sm[data-jsx-ext~=\"23125056293\"]{font-size:0.76923em}p.font-size-md[data-jsx-ext~=\"23125056293\"]{font-size:1em}p.font-size-lg[data-jsx-ext~=\"23125056293\"]{font-size:1.3em}p.font-size-xlg[data-jsx-ext~=\"23125056293\"]{font-size:1.69em}p.font-size-xxlg[data-jsx-ext~=\"23125056293\"]{font-size:2.197em}.title[data-jsx-ext~=\"23125056293\"]{color:blue}.title[data-jsx-ext~=\"23125056293\"] span[data-jsx-ext~=\"23125056293\"]{color:green}.boxes[data-jsx-ext~=\"23125056293\"]:before{content:'';display:table}.boxes[data-jsx-ext~=\"23125056293\"]:after{content:'';display:table;clear:both}.box[data-jsx-ext~=\"23125056293\"]{background-color:green;padding:1em}@media (min-width:48em){.box[data-jsx-ext~=\"23125056293\"]{width:calc(99.9% * 1/7)}.box[data-jsx-ext~=\"23125056293\"]:nth-child(1n){float:left;margin-right:0;clear:none}.box[data-jsx-ext~=\"23125056293\"]:last-child{margin-right:0}.box[data-jsx-ext~=\"23125056293\"]:nth-child(0n){margin-right:0;float:right}.box[data-jsx-ext~=\"23125056293\"]:nth-child(0n + 1){clear:both}}.box--colour-primary[data-jsx-ext~=\"23125056293\"]{background-color:blue}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]{background-color:green}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]{background-color:yellow}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]{background-color:red}.box--colour-primary[data-jsx-ext~=\"23125056293\"]:nth-child(1){background-color:rgb(77, 77, 255)}.box--colour-primary[data-jsx-ext~=\"23125056293\"]:nth-child(2){background-color:rgb(51, 51, 255)}.box--colour-primary[data-jsx-ext~=\"23125056293\"]:nth-child(3){background-color:rgb(25, 25, 255)}.box--colour-primary[data-jsx-ext~=\"23125056293\"]:nth-child(5){background-color:rgb(0, 0, 230)}.box--colour-primary[data-jsx-ext~=\"23125056293\"]:nth-child(6){background-color:rgb(0, 0, 204)}.box--colour-primary[data-jsx-ext~=\"23125056293\"]:nth-child(7){background-color:rgb(0, 0, 179)}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]:nth-child(1){background-color:rgb(77, 166, 77)}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]:nth-child(2){background-color:rgb(51, 153, 51)}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]:nth-child(3){background-color:rgb(25, 141, 25)}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]:nth-child(5){background-color:rgb(0, 115, 0)}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]:nth-child(6){background-color:rgb(0, 102, 0)}.box--colour-secondary[data-jsx-ext~=\"23125056293\"]:nth-child(7){background-color:rgb(0, 90, 0)}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]:nth-child(1){background-color:rgb(255, 255, 77)}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]:nth-child(2){background-color:rgb(255, 255, 51)}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]:nth-child(3){background-color:rgb(255, 255, 25)}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]:nth-child(5){background-color:rgb(230, 230, 0)}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]:nth-child(6){background-color:rgb(204, 204, 0)}.box--colour-tertiary[data-jsx-ext~=\"23125056293\"]:nth-child(7){background-color:rgb(179, 179, 0)}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]:nth-child(1){background-color:rgb(255, 77, 77)}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]:nth-child(2){background-color:rgb(255, 51, 51)}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]:nth-child(3){background-color:rgb(255, 25, 25)}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]:nth-child(5){background-color:rgb(230, 0, 0)}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]:nth-child(6){background-color:rgb(204, 0, 0)}.box--colour-highlight[data-jsx-ext~=\"23125056293\"]:nth-child(7){background-color:rgb(179, 0, 0)}";
__styledJsxDefaultExport.__scopedHash = "23125056293";
module.exports = __styledJsxDefaultExport;

/***/ }),

/***/ 388:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _style = __webpack_require__(76);

var _style2 = _interopRequireDefault(_style);

var _react = __webpack_require__(6);

var _react2 = _interopRequireDefault(_react);

var _ExampleComponent = __webpack_require__(389);

var _ExampleComponent2 = _interopRequireDefault(_ExampleComponent);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function (_ref) {
  var children = _ref.children,
      title = _ref.title;
  return _react2.default.createElement('div', {
    'data-jsx-ext': _ExampleComponent2.default.__scopedHash
  }, _react2.default.createElement('h1', {
    'data-jsx-ext': _ExampleComponent2.default.__scopedHash
  }, title), _react2.default.createElement('p', {
    'data-jsx-ext': _ExampleComponent2.default.__scopedHash
  }, 'Example Component'), children, _react2.default.createElement(_style2.default, {
    styleId: _ExampleComponent2.default.__scopedHash,
    css: _ExampleComponent2.default.__scoped
  }));
};

/***/ }),

/***/ 389:
/***/ (function(module, exports) {

var __styledJsxDefaultExport = new String("");

__styledJsxDefaultExport.__hash = "13322365906";
__styledJsxDefaultExport.__scoped = "";
__styledJsxDefaultExport.__scopedHash = "23322365906";
module.exports = __styledJsxDefaultExport;

/***/ }),

/***/ 390:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var exampleAction = exports.exampleAction = function exampleAction(payload) {
  return {
    type: 'EXAMPLE_ACTION',
    payload: payload
  };
};

/***/ })

},[385]);
            return { page: comp.default }
          })
        