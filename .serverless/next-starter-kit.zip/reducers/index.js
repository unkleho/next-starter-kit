import { combineReducers } from 'redux';

import example from './exampleReducer';

export default combineReducers({
	example,
});
