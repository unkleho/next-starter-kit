
          window.__NEXT_REGISTER_PAGE('/', function() {
            var comp = module.exports =
webpackJsonp([5],{

/***/ 391:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(392);


/***/ }),

/***/ 392:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _react = __webpack_require__(6);

var _react2 = _interopRequireDefault(_react);

var _ExampleApp = __webpack_require__(118);

var _ExampleApp2 = _interopRequireDefault(_ExampleApp);

var _Header = __webpack_require__(119);

var _Header2 = _interopRequireDefault(_Header);

var _withData = __webpack_require__(120);

var _withData2 = _interopRequireDefault(_withData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = (0, _withData2.default)(function (props) {
  return _react2.default.createElement(_ExampleApp2.default, null, _react2.default.createElement(_Header2.default, { pathname: props.url.pathname }), _react2.default.createElement('h1', null, 'Next Starter Kit'));
});

/***/ })

},[391]);
            return { page: comp.default }
          })
        