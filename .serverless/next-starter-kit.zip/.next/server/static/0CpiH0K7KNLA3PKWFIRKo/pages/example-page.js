module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 23);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./routes/index.js
var routes = __webpack_require__(7);

// CONCATENATED MODULE: ./components/Link/Link.js


/* harmony default export */ var Link = (function (props) {
  return external_react_default.a.createElement(routes["Link"], props, props.children);
});
// CONCATENATED MODULE: ./components/Link/index.js
/* concated harmony reexport default */__webpack_require__.d(__webpack_exports__, "a", function() { return Link; });


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("react-apollo");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_base_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9);
/* harmony import */ var _styles_base_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_base_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_helpers_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(10);
/* harmony import */ var _styles_helpers_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_helpers_css__WEBPACK_IMPORTED_MODULE_3__);




/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var children = _ref.children;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("main", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
    name: "viewport",
    content: "initial-scale=1.0, width=device-width"
  })), children);
});

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

var routes = __webpack_require__(11)();

routes.add('example-page', '/example-page/:id');
module.exports = routes;

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./components/Link/index.js + 1 modules
var Link = __webpack_require__(2);

// EXTERNAL MODULE: ./components/Header/Header.css
var Header = __webpack_require__(12);

// CONCATENATED MODULE: ./components/Header/Header.js



/* harmony default export */ var Header_Header = (function (_ref) {
  var pathname = _ref.pathname;
  var menuItems = [{
    name: 'Home',
    url: '/'
  }, {
    name: 'Example Page',
    url: '/example-page'
  }];
  return external_react_default.a.createElement("header", {
    className: "header"
  }, menuItems.map(function (item) {
    return external_react_default.a.createElement(Link["a" /* default */], {
      prefetch: true,
      to: item.url,
      key: item.url
    }, external_react_default.a.createElement("a", {
      className: pathname === item.url ? 'is-active' : undefined
    }, item.name));
  }));
});
// CONCATENATED MODULE: ./components/Header/index.js
/* concated harmony reexport default */__webpack_require__.d(__webpack_exports__, "a", function() { return Header_Header; });


/***/ }),
/* 9 */
/***/ (function(module, exports) {



/***/ }),
/* 10 */
/***/ (function(module, exports) {



/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("next-routes");

/***/ }),
/* 12 */
/***/ (function(module, exports) {



/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("next-redux-wrapper");

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("redux-devtools-extension");

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("redux-thunk");

/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = require("apollo-client");

/***/ }),
/* 20 */
/***/ (function(module, exports) {

module.exports = require("apollo-link-http");

/***/ }),
/* 21 */
/***/ (function(module, exports) {

module.exports = require("apollo-cache-inmemory");

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(38);


/***/ }),
/* 24 */
/***/ (function(module, exports) {



/***/ }),
/* 25 */
/***/ (function(module, exports) {



/***/ }),
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(14);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(5);

// EXTERNAL MODULE: external "next-redux-wrapper"
var external_next_redux_wrapper_ = __webpack_require__(15);
var external_next_redux_wrapper_default = /*#__PURE__*/__webpack_require__.n(external_next_redux_wrapper_);

// EXTERNAL MODULE: external "react-apollo"
var external_react_apollo_ = __webpack_require__(4);

// EXTERNAL MODULE: external "graphql-tag"
var external_graphql_tag_ = __webpack_require__(16);
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_);

// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(3);

// EXTERNAL MODULE: ./pages/example-page.css
var example_page = __webpack_require__(24);

// EXTERNAL MODULE: external "redux-devtools-extension"
var external_redux_devtools_extension_ = __webpack_require__(17);

// EXTERNAL MODULE: external "redux-thunk"
var external_redux_thunk_ = __webpack_require__(18);
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_);

// CONCATENATED MODULE: ./reducers/exampleReducer.js
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var exampleInitialState = {
  count: 0
}; // REDUCERS

/* harmony default export */ var exampleReducer = (function () {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : exampleInitialState;
  var action = arguments.length > 1 ? arguments[1] : undefined;

  switch (action.type) {
    case 'EXAMPLE_ACTION':
      console.log('EXAMPLE_ACTION');
      return state;

    case 'ADD':
      return _objectSpread({}, state, {
        count: state.count + 1
      });

    default:
      return state;
  }
});
// CONCATENATED MODULE: ./reducers/index.js


/* harmony default export */ var reducers = (Object(external_redux_["combineReducers"])({
  example: exampleReducer
}));
// CONCATENATED MODULE: ./lib/store.js




var store_exampleInitialState = {};
var store_initStore = function initStore() {
  var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : store_exampleInitialState;
  return Object(external_redux_["createStore"])(reducers, initialState, Object(external_redux_devtools_extension_["composeWithDevTools"])(Object(external_redux_["applyMiddleware"])(external_redux_thunk_default.a)));
};
// EXTERNAL MODULE: external "@babel/runtime/regenerator"
var regenerator_ = __webpack_require__(13);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator_);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(1);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "apollo-client"
var external_apollo_client_ = __webpack_require__(19);

// EXTERNAL MODULE: external "apollo-link-http"
var external_apollo_link_http_ = __webpack_require__(20);

// EXTERNAL MODULE: external "apollo-cache-inmemory"
var external_apollo_cache_inmemory_ = __webpack_require__(21);

// EXTERNAL MODULE: external "isomorphic-unfetch"
var external_isomorphic_unfetch_ = __webpack_require__(22);
var external_isomorphic_unfetch_default = /*#__PURE__*/__webpack_require__.n(external_isomorphic_unfetch_);

// CONCATENATED MODULE: ./lib/initApollo.js




var apolloClient = null; // Polyfill fetch() on the server (used by apollo-client)

if (true) {
  global.fetch = external_isomorphic_unfetch_default.a;
}

function create(initialState) {
  return new external_apollo_client_["ApolloClient"]({
    // connectToDevTools: process.browser,
    ssrMode: !false,
    // Disables forceFetch on the server (so queries are only run once)
    link: new external_apollo_link_http_["HttpLink"]({
      uri: 'https://api.maas.museum/graphql',
      // Server URL (must be absolute)
      credentials: 'same-origin' // Additional fetch() options like `credentials` or `headers`

    }),
    cache: new external_apollo_cache_inmemory_["InMemoryCache"]().restore(initialState || {})
  });
}

function initApollo(initialState) {
  // Make sure to create a new client for every server-side request so that data
  // isn't shared between connections (which would be bad)
  if (true) {
    return create(initialState);
  } // Reuse client on the client-side


  if (!apolloClient) {
    apolloClient = create(initialState);
  }

  return apolloClient;
}
// CONCATENATED MODULE: ./lib/withApollo.js


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function withApollo_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { withApollo_defineProperty(target, key, source[key]); }); } return target; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function withApollo_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 // Gets the display name of a JSX component for dev tools

function getComponentDisplayName(Component) {
  return Component.displayName || Component.name || 'Unknown';
}

/* harmony default export */ var withApollo = (function (ComposedComponent) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    _inherits(WithData, _React$Component);

    _createClass(WithData, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = _asyncToGenerator(
        /*#__PURE__*/
        regenerator_default.a.mark(function _callee(ctx) {
          var serverState, composedInitialProps, apollo;
          return regenerator_default.a.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  // Initial serverState with apollo (empty)
                  serverState = {
                    apollo: {
                      data: {}
                    }
                  }; // Evaluate the composed component's getInitialProps()

                  composedInitialProps = {};

                  if (!ComposedComponent.getInitialProps) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 5;
                  return ComposedComponent.getInitialProps(ctx);

                case 5:
                  composedInitialProps = _context.sent;

                case 6:
                  if (false) {}

                  apollo = initApollo();
                  _context.prev = 8;
                  _context.next = 11;
                  return Object(external_react_apollo_["getDataFromTree"])(external_react_default.a.createElement(external_react_apollo_["ApolloProvider"], {
                    client: apollo
                  }, external_react_default.a.createElement(ComposedComponent, composedInitialProps)), {
                    router: {
                      asPath: ctx.asPath,
                      pathname: ctx.pathname,
                      query: ctx.query
                    }
                  });

                case 11:
                  _context.next = 15;
                  break;

                case 13:
                  _context.prev = 13;
                  _context.t0 = _context["catch"](8);

                case 15:
                  // getDataFromTree does not call componentWillUnmount
                  // head side effect therefore need to be cleared manually
                  head_default.a.rewind(); // Extract query data from the Apollo store

                  serverState = {
                    apollo: {
                      data: apollo.cache && apollo.cache.extract()
                    }
                  };

                case 17:
                  return _context.abrupt("return", withApollo_objectSpread({
                    serverState: serverState
                  }, composedInitialProps));

                case 18:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this, [[8, 13]]);
        }));

        return function getInitialProps(_x) {
          return _getInitialProps.apply(this, arguments);
        };
      }()
    }]);

    function WithData(props) {
      var _this;

      _classCallCheck(this, WithData);

      _this = _possibleConstructorReturn(this, _getPrototypeOf(WithData).call(this, props));
      _this.apollo = initApollo(_this.props.serverState.apollo.data);
      return _this;
    }

    _createClass(WithData, [{
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(external_react_apollo_["ApolloProvider"], {
          client: this.apollo
        }, external_react_default.a.createElement(ComposedComponent, this.props));
      }
    }]);

    return WithData;
  }(external_react_default.a.Component), withApollo_defineProperty(_class, "displayName", "WithData(".concat(getComponentDisplayName(ComposedComponent), ")")), _temp;
});
// EXTERNAL MODULE: ./components/examples/ExampleApp.js
var ExampleApp = __webpack_require__(6);

// EXTERNAL MODULE: ./components/Link/index.js + 1 modules
var Link = __webpack_require__(2);

// EXTERNAL MODULE: ./components/Header/index.js + 1 modules
var Header = __webpack_require__(8);

// EXTERNAL MODULE: ./components/examples/ExampleComponent.css
var ExampleComponent = __webpack_require__(25);

// CONCATENATED MODULE: ./components/examples/ExampleComponent.js


/* harmony default export */ var examples_ExampleComponent = (function (_ref) {
  var children = _ref.children,
      title = _ref.title;
  return external_react_default.a.createElement("div", null, external_react_default.a.createElement("h1", null, title), external_react_default.a.createElement("p", null, "Example Component"), children);
});
// CONCATENATED MODULE: ./actions/exampleActions.js
var exampleAction = function exampleAction(payload) {
  return {
    type: 'EXAMPLE_ACTION',
    payload: payload
  };
};
var addCount = function addCount() {
  return function (dispatch) {
    return dispatch({
      type: 'ADD'
    });
  };
};
// CONCATENATED MODULE: ./pages/example-page.js


function example_page_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { example_page_defineProperty(target, key, source[key]); }); } return target; }

function _templateObject() {
  var data = _taggedTemplateLiteral(["\n\tquery {\n\t\tobjects(limit: 10) {\n\t\t\tdisplayTitle\n\t\t}\n\t}\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }

function example_page_typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { example_page_typeof = function _typeof(obj) { return typeof obj; }; } else { example_page_typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return example_page_typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function example_page_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function example_page_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function example_page_createClass(Constructor, protoProps, staticProps) { if (protoProps) example_page_defineProperties(Constructor.prototype, protoProps); if (staticProps) example_page_defineProperties(Constructor, staticProps); return Constructor; }

function example_page_possibleConstructorReturn(self, call) { if (call && (example_page_typeof(call) === "object" || typeof call === "function")) { return call; } return example_page_assertThisInitialized(self); }

function example_page_getPrototypeOf(o) { example_page_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return example_page_getPrototypeOf(o); }

function example_page_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) example_page_setPrototypeOf(subClass, superClass); }

function example_page_setPrototypeOf(o, p) { example_page_setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return example_page_setPrototypeOf(o, p); }

function example_page_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function example_page_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

















var example_page_ExamplePage =
/*#__PURE__*/
function (_Component) {
  example_page_inherits(ExamplePage, _Component);

  function ExamplePage() {
    var _this;

    example_page_classCallCheck(this, ExamplePage);

    _this = example_page_possibleConstructorReturn(this, example_page_getPrototypeOf(ExamplePage).call(this));

    example_page_defineProperty(example_page_assertThisInitialized(example_page_assertThisInitialized(_this)), "handleCountClick", function () {
      _this.props.addCount();
    });

    _this.state = {};
    return _this;
  }

  example_page_createClass(ExamplePage, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          id = _this$props.id,
          router = _this$props.router,
          objects = _this$props.objects;
      var sizes = ['xxs', 'xs', 'sm', 'md', 'lg', 'xlg', 'xxlg'];
      var colours = ['primary', 'secondary', 'tertiary', 'highlight'];
      return external_react_default.a.createElement(ExampleApp["a" /* default */], null, external_react_default.a.createElement(Header["a" /* default */], {
        pathname: router.pathname
      }), external_react_default.a.createElement("h1", {
        className: "title"
      }, "Page ", external_react_default.a.createElement("span", null, id)), external_react_default.a.createElement("h2", null, "Style Guide"), external_react_default.a.createElement("h3", null, "Type Scale"), sizes.map(function (size) {
        return external_react_default.a.createElement("p", {
          className: "font-size-".concat(size),
          key: "font-size-".concat(size)
        }, "font-size-".concat(size));
      }), external_react_default.a.createElement("h3", null, "Colours"), colours.map(function (colour) {
        return external_react_default.a.createElement("div", {
          className: "boxes",
          key: "boxes-".concat(colour)
        }, external_react_default.a.createElement("h4", null, colour), external_react_default.a.createElement("div", null, _toConsumableArray(Array(7)).map(function (shade, i) {
          return external_react_default.a.createElement("div", {
            className: "box box--colour-".concat(colour),
            key: "box--colour-".concat(colour, "-").concat(i)
          });
        })));
      }), external_react_default.a.createElement("h2", null, "Example Component"), external_react_default.a.createElement(examples_ExampleComponent, {
        title: "Title"
      }), external_react_default.a.createElement(Link["a" /* default */], {
        to: "/example-page/1"
      }, external_react_default.a.createElement("a", null, "Example Page 1 Link")), external_react_default.a.createElement("h2", null, "Redux Test"), external_react_default.a.createElement("p", null, "this.props.count: ", this.props.count), external_react_default.a.createElement("button", {
        onClick: this.handleCountClick
      }, "Click here to increase"), external_react_default.a.createElement("h2", null, "dotenv Test"), external_react_default.a.createElement("p", null, process.env.TEST), external_react_default.a.createElement("h2", null, "GraphQL Test"), external_react_default.a.createElement("p", null, process.env.GRAPHQL_URL), external_react_default.a.createElement("ul", null, objects && objects.map(function (_ref, i) {
        var displayTitle = _ref.displayTitle;
        return external_react_default.a.createElement("li", {
          key: i
        }, displayTitle);
      })));
    }
  }], [{
    key: "getInitialProps",
    value: function getInitialProps(_ref2) {
      var _ref2$query$id = _ref2.query.id,
          id = _ref2$query$id === void 0 ? null : _ref2$query$id,
          store = _ref2.store,
          isServer = _ref2.isServer;
      store.dispatch(exampleAction('payload'));
      console.log(isServer);
      return {
        id: id
      };
    }
  }]);

  return ExamplePage;
}(external_react_["Component"]);

var example_page_mapDispatchToProps = function mapDispatchToProps(dispatch) {
  return {
    addCount: Object(external_redux_["bindActionCreators"])(addCount, dispatch)
  };
};

var allObjects = external_graphql_tag_default()(_templateObject()); // The `graphql` wrapper executes a GraphQL query and makes the results
// available on the `data` prop of the wrapped component (ExamplePage)

/* harmony default export */ var pages_example_page = __webpack_exports__["default"] = (external_next_redux_wrapper_default()(store_initStore, function (state) {
  return state.example;
}, example_page_mapDispatchToProps)(withApollo(Object(external_react_apollo_["graphql"])(allObjects, {
  props: function props(_ref3) {
    var data = _ref3.data;
    return example_page_objectSpread({}, data);
  }
})(Object(router_["withRouter"])(example_page_ExamplePage)))));

/***/ })
/******/ ]);