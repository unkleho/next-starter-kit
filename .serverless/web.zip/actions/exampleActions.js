export const exampleAction = (payload) => {
  return {
    type: 'EXAMPLE_ACTION',
    payload,
  }
}
