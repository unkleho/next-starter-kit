import example from './exampleReducer';

export default {
  example,
}
